import timeit

print "Comparing times to create a wave table using either NumPy or a Python list comprehension."
print "This may take several seconds."

numpy_duration = timeit.timeit('numpy.sin( numpy.arange(0.0, 2*numpy.pi, numpy.pi/1000))', number=1000, setup="import numpy")
print "NumPy took", numpy_duration, "seconds."

list_duration = timeit.timeit('[math.sin(i*math.pi/10000.0) for i in range(20000)]', number=1000, setup="import math")
print "List comprehension took", list_duration, "seconds."

print "Estimated numpy speedup:", list_duration/numpy_duration
